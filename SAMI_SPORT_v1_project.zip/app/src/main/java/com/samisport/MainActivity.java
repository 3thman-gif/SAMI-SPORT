package com.samisport;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, table, teamsBox; ArrayList<Team> teams=new ArrayList<>(); ArrayList<Game> games=new ArrayList<>();
    android.content.SharedPreferences sp;
    static class Team { String name; int played, gf, ga, pts; Team(String n){name=n;} int gd(){return gf-ga;} }
    static class Game { String a,b; int x,y; Game(String a,String b,int x,int y){this.a=a;this.b=b;this.x=x;this.y=y;} }

    public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("data",0); load(); build(); render();}

    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(18,16,18,16); t.setGravity(Gravity.CENTER); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,12,12,12);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sv=new ScrollView(this); LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        TextView title=tv("⚽ SAMI SPORT",24); title.setGravity(Gravity.CENTER); content.addView(title);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button add=btn("➕ إضافة فريق"); add.setOnClickListener(v->addTeam()); Button game=btn("⚽ تسجيل مباراة"); game.setOnClickListener(v->addGame());
        actions.addView(add,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(game,new LinearLayout.LayoutParams(0,-2,1)); content.addView(actions);
        content.addView(tv("جدول الترتيب",20));
        HorizontalScrollView hsv=new HorizontalScrollView(this); table=new LinearLayout(this); table.setOrientation(LinearLayout.VERTICAL); hsv.addView(table); content.addView(hsv);
        content.addView(tv("إدارة الفرق",20)); teamsBox=new LinearLayout(this); teamsBox.setOrientation(LinearLayout.VERTICAL); content.addView(teamsBox);
        content.addView(tv("سجل المباريات",20)); content.setPadding(4,4,4,20); sv.addView(content); root.addView(sv); setContentView(root);
    }

    void render(){
        table.removeAllViews(); teamsBox.removeAllViews();
        String[] h={"الفريق","لعب","له","عليه","النقاط","الفارق"};
        LinearLayout hr=new LinearLayout(this); hr.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(String s:h){TextView t=tv(s,15); t.setTypeface(null,1); hr.addView(t,new LinearLayout.LayoutParams(150,-2));} table.addView(hr);
        ArrayList<Team> sorted=new ArrayList<>(teams); Collections.sort(sorted,(p,q)->{int z=Integer.compare(q.pts,p.pts); if(z==0)z=Integer.compare(q.gd(),p.gd()); if(z==0)z=Integer.compare(q.gf,p.gf); return z;});
        for(Team tm:sorted){LinearLayout r=new LinearLayout(this); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); String[] vals={tm.name,""+tm.played,""+tm.gf,""+tm.ga,""+tm.pts,(tm.gd()>0?"+":"")+tm.gd()}; for(String s:vals)r.addView(tv(s,14),new LinearLayout.LayoutParams(150,-2)); table.addView(r);}
        for(Team tm:teams){LinearLayout r=new LinearLayout(this); r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); TextView n=tv(tm.name,16); r.addView(n,new LinearLayout.LayoutParams(0,-2,1)); Button e=btn("✏️"); e.setOnClickListener(v->editTeam(tm)); Button d=btn("🗑️"); d.setOnClickListener(v->{teams.remove(tm); games.removeIf(g->g.a.equals(tm.name)||g.b.equals(tm.name)); save(); render();}); r.addView(e);r.addView(d);teamsBox.addView(r);}
        for(Game g:games){ TextView x=tv(g.a+"  "+g.x+" - "+g.y+"  "+g.b,15); teamsBox.addView(x); }
    }

    void addTeam(){ final EditText e=new EditText(this); e.setHint("اسم الفريق"); new AlertDialog.Builder(this).setTitle("إضافة فريق").setView(e).setPositiveButton("إضافة",(d,w)->{if(e.getText().length()>0){teams.add(new Team(e.getText().toString()));save();render();}}).setNegativeButton("إلغاء",null).show(); }
    void editTeam(Team t){ final EditText e=new EditText(this); e.setText(t.name); new AlertDialog.Builder(this).setTitle("تعديل اسم الفريق").setView(e).setPositiveButton("حفظ",(d,w)->{String old=t.name,n=e.getText().toString(); if(!n.isEmpty()){t.name=n; for(Game g:games){if(g.a.equals(old))g.a=n;if(g.b.equals(old))g.b=n;} save();render();}}).setNegativeButton("إلغاء",null).show(); }
    void addGame(){
        if(teams.size()<2){new AlertDialog.Builder(this).setMessage("أضف فريقين على الأقل أولاً.").setPositiveButton("حسنًا",null).show();return;}
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(20,5,20,5);
        Spinner a=new Spinner(this), b=new Spinner(this); ArrayList<String> ns=new ArrayList<>(); for(Team t:teams)ns.add(t.name); ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ns); a.setAdapter(ad);b.setAdapter(ad);
        EditText x=new EditText(this),y=new EditText(this); x.setInputType(2);y.setInputType(2);x.setHint("أهداف الفريق الأول");y.setHint("أهداف الفريق الثاني");
        l.addView(a);l.addView(x);l.addView(b);l.addView(y);
        new AlertDialog.Builder(this).setTitle("تسجيل مباراة").setView(l).setPositiveButton("حفظ",(d,w)->{try{int gx=Integer.parseInt(x.getText().toString()),gy=Integer.parseInt(y.getText().toString()); games.add(new Game(a.getSelectedItem().toString(),b.getSelectedItem().toString(),gx,gy));recalc();save();render();}catch(Exception ex){}}).setNegativeButton("إلغاء",null).show();
    }
    void recalc(){for(Team t:teams){t.played=t.gf=t.ga=t.pts=0;} for(Game g:games){Team a=find(g.a),b=find(g.b);if(a==null||b==null)continue;a.played++;b.played++;a.gf+=g.x;a.ga+=g.y;b.gf+=g.y;b.ga+=g.x;if(g.x>g.y)a.pts+=3;else if(g.x<g.y)b.pts+=3;else{a.pts++;b.pts++;}}}
    Team find(String n){for(Team t:teams)if(t.name.equals(n))return t;return null;}
    void save(){StringBuilder s=new StringBuilder();for(Team t:teams)s.append(t.name.replace("|"," ")).append("|");sp.edit().putString("teams",s.toString()).apply();}
    void load(){String s=sp.getString("teams","");if(!s.isEmpty())for(String n:s.split("\\|"))if(!n.isEmpty())teams.add(new Team(n));}
}