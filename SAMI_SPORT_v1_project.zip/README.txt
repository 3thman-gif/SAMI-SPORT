SAMI SPORT - النسخة الأولى
مشروع Android Studio جاهز للبناء.
الواجهة عربية RTL، إضافة/تعديل/حذف الفرق، تسجيل النتائج وحساب الترتيب.
لبناء APK: افتح المجلد في Android Studio ثم Build > Build APK(s).
